import React, { Component } from 'react';
import { TabContent, TabPane, Nav, NavItem, NavLink, Row, Col } from 'reactstrap';
import classnames from 'classnames';
import ParametersFormula from './ParametersFormula';
import WeightFormula from './WeightFormula';

export default class Menu extends Component {
	constructor() {
		super();
		this.state = {
			url: 'http://ec2-3-15-171-237.us-east-2.compute.amazonaws.com:8080/?',
			activeTab: '1'
		};
		this.handleToggle = this.handleToggle.bind(this);
	}

	handleToggle(tab) {
		if (this.state.activeTab !== tab) this.setState({ activeTab: tab });
	}

	render() {
		return (
			<div>
				<Nav tabs className='Menu'>
					<NavItem>
						<NavLink
							className={classnames({
								active: this.state.activeTab === '1'
							})}
							onClick={() => {
								this.handleToggle('1');
							}}
						>
							כלל המדדים
						</NavLink>
					</NavItem>
					<NavItem>
						<NavLink
							className={classnames({
								active: this.state.activeTab === '2'
							})}
							onClick={() => {
								this.handleToggle('2');
							}}
						>
							הערכת משקל
						</NavLink>
					</NavItem>
				</Nav>
				<TabContent activeTab={this.state.activeTab}>
					<TabPane tabId='1'>
						<Row>
							<Col sm='12'>
								<p className='Menu-Formula'>
									HADLOCK 1985 & SUOKA 2014 חישוב הערכת המשקל מבוסס
								</p>
								<ParametersFormula url={this.state.url} />
							</Col>
						</Row>
					</TabPane>
					<TabPane tabId='2'>
						<Row>
							<Col sm='12'>
								<p className='Menu-Formula'>
									HADLOCK 1985 & SUOKA 2014 חישוב הערכת המשקל מבוסס
								</p>
								<WeightFormula url={this.state.url} />
							</Col>
						</Row>
					</TabPane>
				</TabContent>
			</div>
		);
	}
}
