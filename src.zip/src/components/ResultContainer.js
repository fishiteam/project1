import React from 'react';
import Result from './Result';

export default function ResultContainer(props) {
	const results = props.data.map(result => (
		<Result
			key={result.id}
			name={result.name}
			value={result.value.toFixed(2)}
		/>
	));

	return <div className='Result-Container'>{results}</div>;
}
