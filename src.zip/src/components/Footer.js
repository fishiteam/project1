import React from 'react';

export default function Footer() {
	return (
		<div className='Footer'>
			<p className='Footer-Contact'>ליצירת קשר</p>
			<p className='Footer-Mail'>ettyspiegel@gmail.com</p>
		</div>
	);
}
