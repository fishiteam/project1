import React, { Component } from 'react';
import { Form, FormGroup, Label, Input } from 'reactstrap';
import ResultContainer from './ResultContainer';

export default class WeightFormula extends Component {
	constructor() {
		super();
		this.state = {
			week: {
				value: '',
				valid: false
			},
			day: {
				value: '',
				valid: false
			},
			efw: {
				value: '',
				valid: false
			},
			apiData: null,
			changed: false
		};
		this.handleChange = this.handleChange.bind(this);
		this.validation = this.validation.bind(this);
		this.apiConnection = this.apiConnection.bind(this);
	}

	handleChange(event) {
		event.preventDefault();
		const { name, value } = event.target;
		name === 'week'
			? this.setState({
					week: {
						value: value,
						valid: this.validation('week', value)
					},
					day: {
						value: this.state.day.value,
						valid: this.validation('day', this.state.day.value)
					},
					changed: true
			  })
			: this.setState({
					[name]: {
						value: value,
						valid: this.validation(name, value)
					},
					changed: true
			  });
	}

	validation(parameterName, value) {
		if (parameterName === 'week') {
			return /^(1[4-9]|[2-3][0-9]|4[0-2])$/.test(value);
		} else if (parameterName === 'day') {
			if (this.state.week.value === '14') {
				return /^[1-6]$/.test(value);
			} else {
				return /^[0-6]$/.test(value);
			}
		} else {
			return /^[0-9][1-9]*(.[0-9]*)?$/.test(value);
		}
	}

	apiConnection(url) {
		fetch(url)
			.then(response => response.json())
			.then(data => {
				this.setState({
					apiData: data.result,
					changed: false
				});
			});
	}

	render() {
		let results = this.state.apiData;
		let url = null;
		if (
			this.state.week.valid &&
			this.state.day.valid &&
			this.state.efw.valid
		) {
			url =
				this.props.url +
				'week=' +
				this.state.week.value +
				'&day=' +
				this.state.day.value +
				'&efw=' +
				this.state.efw.value;
			if (this.state.changed) this.apiConnection(url);
			if (this.state.apiData !== null)
				results = <ResultContainer data={this.state.apiData} />;
		} else {
			results = <p className='Details'>אנא מלא את כל הפרמטרים</p>;
		}

		return (
			<div className='Form'>
				<Form>
					<FormGroup>
						<Label>Week</Label>
						<Input
							valid={this.state.week.valid}
							invalid={
								!this.state.week.valid &&
								this.state.week.value !== ''
							}
							type='text'
							placeholder='Pregnancy Week'
							name='week'
							onChange={this.handleChange}
							required
						/>
					</FormGroup>
					<FormGroup>
						<Label>Day</Label>
						<Input
							valid={this.state.day.valid}
							invalid={
								!this.state.day.valid &&
								this.state.day.value !== ''
							}
							type='text'
							placeholder='Pregnancy Day'
							name='day'
							onChange={this.handleChange}
							required
						/>
					</FormGroup>
					<FormGroup>
						<Label>EFW</Label>
						<Input
							valid={this.state.efw.valid}
							invalid={
								!this.state.efw.valid &&
								this.state.efw.value !== ''
							}
							type='text'
							placeholder='Estimated Fetal Weight'
							name='efw'
							onChange={this.handleChange}
							required
						/>
					</FormGroup>
				</Form>
				{results}
			</div>
		);
	}
}
