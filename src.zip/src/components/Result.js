import React from 'react';

export default function Result(props) {
	return (
		<div className='Result'>
			<p className='Result-Title'>{props.name}</p>
			<p className='Result-Text'>{props.value}</p>
		</div>
	);
}
