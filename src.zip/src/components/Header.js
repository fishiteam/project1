import React from 'react';

export default function Header() {
	return (
		<div className='Header'>
			<p className='Header-Title'>עקומת גדילת עוברים</p>
			<p className='Header-Title'>שפיגל - יגל</p>
			<hr className='Space' />
			<p className='Header-Description'>
				מחשבון זה מבוסס על מדידות עוברים ברחם
			</p>
			<p className='Header-Description'>
				מחשבון זה משמש כלי עזר וכפוף לשקול דעתו של הרופא המומחה
			</p>
			<p className='Header-Instructions'>
				Reference: Daniel-Spiegel E, Mandel M, Yagel S.Fetal Weight
				Charts in the Israeli Population. Harefuah. 2018 Feb;157(2):
				77-80.
			</p>
		</div>
	);
}
