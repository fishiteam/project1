import React, { Component } from 'react';
import { Form, FormGroup, Label, Input } from 'reactstrap';
import ResultContainer from './ResultContainer';

export default class ParametersFormula extends Component {
	constructor() {
		super();
		this.state = {
			week: {
				value: '',
				valid: false
			},
			day: {
				value: '',
				valid: false
			},
			fl: {
				value: '',
				valid: false
			},
			ac: {
				value: '',
				valid: false
			},
			hc: {
				value: '',
				valid: false
			},
			bpd: {
				value: '',
				valid: false
			},
			apiData: null,
			changed: false
		};
		this.handleChange = this.handleChange.bind(this);
		this.validation = this.validation.bind(this);
		this.apiConnection = this.apiConnection.bind(this);
	}

	handleChange(event) {
		event.preventDefault();
		const { name, value } = event.target;
		name === 'week'
			? this.setState({
					week: {
						value: value,
						valid: this.validation('week', value)
					},
					day: {
						value: this.state.day.value,
						valid: this.validation('day', this.state.day.value)
					},
					changed: true
			  })
			: this.setState({
					[name]: {
						value: value,
						valid: this.validation(name, value)
					},
					changed: true
			  });
	}

	validation(parameterName, value) {
		if (parameterName === 'week') {
			return /^(1[4-9]|[2-3][0-9]|4[0-2])$/.test(value);
		} else if (parameterName === 'day') {
			if (this.state.week.value === '14') {
				return /^[1-6]$/.test(value);
			} else {
				return /^[0-6]$/.test(value);
			}
		} else {
			return /^[0-9][1-9]*(.[0-9]*)?$/.test(value);
		}
	}

	apiConnection(url) {
		fetch(url)
			.then(response => response.json())
			.then(data => {
				this.setState({
					apiData: data.result,
					changed: false
				});
			});
	}

	render() {
		let results = this.state.apiData;
		let url = null;
		if (
			this.state.week.valid &&
			this.state.day.valid &&
			this.state.fl.valid &&
			this.state.ac.valid &&
			this.state.hc.valid &&
			this.state.bpd.valid
		) {
			url =
				this.props.url +
				'week=' +
				this.state.week.value +
				'&day=' +
				this.state.day.value +
				'&FL=' +
				this.state.fl.value +
				'&AC=' +
				this.state.ac.value +
				'&HC=' +
				this.state.hc.value +
				'&BPD=' +
				this.state.bpd.value;
			if (this.state.changed) this.apiConnection(url);
			if (this.state.apiData !== null)
				results = <ResultContainer data={this.state.apiData} />;
		} else {
			results = <p className='Details'>אנא מלא את כל הפרמטרים</p>;
		}

		return (
			<div className='Form'>
				<Form>
					<FormGroup>
						<Label>Week</Label>
						<Input
							valid={this.state.week.valid}
							invalid={
								!this.state.week.valid &&
								this.state.week.value !== ''
							}
							type='text'
							placeholder='Pregnancy Week'
							name='week'
							onChange={this.handleChange}
							required
						/>
					</FormGroup>
					<FormGroup>
						<Label>Day</Label>
						<Input
							valid={this.state.day.valid}
							invalid={
								!this.state.day.valid &&
								this.state.day.value !== ''
							}
							type='text'
							placeholder='Pregnancy Day'
							name='day'
							onChange={this.handleChange}
							required
						/>
					</FormGroup>
					<FormGroup>
						<Label>FL</Label>
						<Input
							valid={this.state.fl.valid}
							invalid={
								!this.state.fl.valid &&
								this.state.fl.value !== ''
							}
							type='text'
							placeholder='Femur Length'
							name='fl'
							onChange={this.handleChange}
							required
						/>
					</FormGroup>
					<FormGroup>
						<Label>AC</Label>
						<Input
							valid={this.state.ac.valid}
							invalid={
								!this.state.ac.valid &&
								this.state.ac.value !== ''
							}
							type='text'
							placeholder='Abdominal Circumference'
							name='ac'
							onChange={this.handleChange}
							required
						/>
					</FormGroup>
					<FormGroup>
						<Label>HC</Label>
						<Input
							valid={this.state.hc.valid}
							invalid={
								!this.state.hc.valid &&
								this.state.hc.value !== ''
							}
							type='text'
							placeholder='Head Circumference'
							name='hc'
							onChange={this.handleChange}
							required
						/>
					</FormGroup>
					<FormGroup>
						<Label>BPD</Label>
						<Input
							valid={this.state.bpd.valid}
							invalid={
								!this.state.bpd.valid &&
								this.state.bpd.value !== ''
							}
							type='text'
							placeholder='Biparietal Diameter'
							name='bpd'
							onChange={this.handleChange}
							required
						/>
					</FormGroup>
				</Form>
				{results}
			</div>
		);
	}
}
