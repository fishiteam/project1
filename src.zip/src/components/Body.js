import React from 'react'
import Menu from './Menu'

export default function Body() {
	return (
		<div className='Body'>
			<Menu />
		</div>
	)
}
