function isInt(n)
{
   return n % 1 === 0;
}

exports.validateQuantiles = function (qBPD, qHC, qAC, qFL, qEFW)
{
        var errorMsg = "";
        if (qBPD <= 0 || qBPD >= 100 || qHC <= 0 || qHC >=100 || qAC <=0 ||
                 qAC >=100 || qFL <= 0 || qFL >= 100 || qEFW <=0 || qEFW >=100)
                errorMsg = "error with measurements";

        return errorMsg;
};

exports.validateTime = function (week, day)
{
        var errorMsg = "";
        if (week == null)
                errorMsg = "week is missing";
        else if (day == null)
                errorMsg = "day is missing";
        else if (!Number(week) && week != 0)
                errorMsg = "week must be a number";
        else if (!Number(day) && day != 0)
                errorMsg = "day must be a number";
        else if (!isInt(week))
                errorMsg = "week is not an integer";
        else if (!isInt(day))
                errorMsg = "day is not an integer";
        else if (week < 0 || week > 42)
                errorMsg = "week must be between 0-42";
        else if (day < 0 || day > 6)
                errorMsg = "day must be between 0-6";
        else if (week == 42 && day != 0)
                errorMsg = "only day = 0 on week 42 is permitted";

        return errorMsg;
};

exports.validateParameters = function (parameters)
{
        var errorMsg = "";
        if (parameters.FL == null)
                errorMsg = "FL is missing";
        else if (parameters.AC == null)
                errorMsg = "AC is missing";
        else if (parameters.HC == null)
                errorMsg = "HC is missing";
        else if (parameters.BPD == null)
                errorMsg = "BPD is missing";
        else if (!Number(parameters.FL) && parameters.FL != 0)
                errorMsg = "FL must be a number";
        else if (!Number(parameters.AC) && parameters.AC != 0)
                errorMsg = "AC must be a number";
        else if (!Number(parameters.HC) && parameters.HC != 0)
                errorMsg = "HC must be a number";
        else if (!Number(parameters.BPD) && parameters.BPD != 0)
                errorMsg = "BPD must be a number";

        return errorMsg;
};
