var http = require('http');
var url = require('url');
var fs = require("fs");
var myMath = require('./myModules/myMathMod');
var validations = require ('./myModules/validationMod');
var statusCode;

http.createServer(function (req, res) {
        var parameters = url.parse(req.url, true).query;
        var jsonResponse;
        msg = validations.validateTime(parameters.week, parameters.day);
        if (msg != "")
                jsonResponse =  sendError(msg);

        else if (parameters.efw)
                jsonResponse = getEstimation(parameters);
        else
                jsonResponse = getFullCalc(parameters);

        res.writeHead(statusCode, {'Content-Type': 'application/json'});
        res.writeHead(statusCode, {'Access-Control-Allow-Origin': '*'});
    res.end(jsonResponse);
}).listen(8080);


function getEstimation(parameters)
{
        statusCode = 200;
        var result = getMean_SD(String(parameters.week), String(parameters.day));
        var quantile = myMath.normalcdf(result[1], result[2], parameters.efw);
        return JSON.stringify(
        {
                //"quantil": quantile*100 + "%",
                //"SD": myMath.NormSInv(quantile)
                "result": [
                        { id: 1, name: 'EFW Quantile', value: quantile*100 },
                        { id: 2, name: 'EFW SD', value:  myMath.NormSInv(quantile)}
                ]
        });
}

function getMean_SD(week, day)
{
        var data = fs.readFileSync("./Data/quickCalc", "utf8")
        var formatedData = data.split('\n');
        for (var i = 0; i < formatedData.length; i++)
                if (week == formatedData[i].slice(0,2) && ((day == formatedData[i][3]) || (day == "0" && formatedData[i][3] == " ")))
                        return formatedData[i].split('\t');
}

function get_SourceRow(week, day)
{
        var data = fs.readFileSync("./Data/SourceData", "utf8")
        var formatedData = data.split('\n');

        for (var i = 0; i < formatedData.length; i++)
        {
                var row = formatedData[i].split('\t');
                if (row[0] == week && row[1] == day)
                        return row;
        }
        return "Error";
}

function getFullCalc(parameters)
{

        var msg = validations.validateParameters(parameters);
        if (msg != "")
                return sendError(msg);

        msg = validations.validateTime(parameters.week, parameters.day);
        if (msg != "")
                return sendError(msg);

        var efw = calcEFW(Number(parameters.week),Number(parameters.day),
                        Number(parameters.FL),Number(parameters.AC),
                        Number(parameters.HC),Number(parameters.BPD));

        var dataRow = get_SourceRow(parameters.week, parameters.day);

        if (dataRow == "Error")
                return sendError("can't find week or day on source data!");

        var qBPD = myMath.normalcdf(0, 1, ((parameters.BPD - dataRow[5]) / dataRow[6])) * 100;
        var qHC = myMath.normalcdf(0, 1, ((parameters.HC - dataRow[9]) / dataRow[10])) * 100;
        var qAC = myMath.normalcdf(0, 1, ((parameters.AC - dataRow[3]) / dataRow[4])) * 100;
        var qFL = myMath.normalcdf(0, 1, ((parameters.FL - dataRow[7]) / dataRow[8])) * 100;
        var qEFW = myMath.normalcdf(0, 1, ((efw - dataRow[11]) / dataRow[12])) * 100;

        msg = validations.validateQuantiles(qBPD, qHC, qAC, qFL, qEFW);

        if (msg != "")
                return sendError(msg);

        statusCode = 200;
//      return JSON.stringify(
//      {
        //      "quantileBPD": qBPD + "%",
        //      "quantileHC": qHC + "%",
        //      "quantileAC": qAC + "%",
        //      "quantileFL": qFL + "%",
//              "SDBPD": myMath.NormSInv(qBPD/100),
  //              "SDHC": myMath.NormSInv(qHC/100),
    //            "SDAC": myMath.NormSInv(qAC/100),
      //          "SDFL": myMath.NormSInv(qFL/100),
        //      "EFW": efw,
        //      "quantiles": qEFW + "%",
        //      "SD": myMath.NormSInv(qEFW/100)
//      });
        return JSON.stringify(
        {
                 "result": [
                        { id: 1, name: 'BPD Quantile', value: qBPD },
                        { id: 2, name: 'HC Quantile', value: qHC },
                        { id: 3, name: 'AC Quantile', value: qAC },
                        { id: 4, name: 'FL Quantile', value: qFL },
                        { id: 5, name: 'BPD SD', value: myMath.NormSInv(qBPD/100) },
                        { id: 6, name: 'HC SD', value: myMath.NormSInv(qHC/100) },
                        { id: 7, name: 'AC SD', value: myMath.NormSInv(qAC/100) },
                        { id: 8, name: 'FL SD', value: myMath.NormSInv(qFL/100) },
                        { id: 9, name: 'EFW Quantile', value: qEFW },
                        { id: 10, name: 'EFW SD', value: myMath.NormSInv(qEFW/100) },
                        { id: 11, name: 'EFW', value: efw }
                ]
        });
}

function sendError(msg)
{
        statusCode = 400;
        return JSON.stringify(
        {
                //"error": msg
                "result": [
                        {id: 1 , name : 'Error', value : msg }
                ]
        });

}

function calcEFW(week, day, fl, ac, hc, bpd)
{
        var ans;
        if (week < 31)
        {
                ans = 1.326 + (0.00107*hc) + (0.00438*ac) + (0.0158*fl) - (0.0000326*ac*fl)
                ans = Math.pow(10,ans);
        }
        else
        {
                ans = -3466.586 + 14.43568*bpd + 3.167604*hc + 192.3903*Math.pow(ac/100,2) + 29.2856*fl;
        }
        return ans;
}
